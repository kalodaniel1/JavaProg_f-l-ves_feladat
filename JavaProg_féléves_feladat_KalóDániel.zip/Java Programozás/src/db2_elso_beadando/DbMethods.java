package db2_elso_beadando;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.Path;
import com.itextpdf.text.pdf.parser.clipper.Paths;


public class DbMethods {
	
	private Statement s = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;
	private Formatter x;
	private Checker c = new Checker();
	
	public AllTM ReadAllData() {
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","Rendsz�ma","N�v","Sz�let�si id�","V�ros","Magass�g"};
		AllTM atm = new AllTM(alltmn, 0);
		String nev="", szulido="", lak="", cim="", mikor="";
		int rid=0, magassag=0;
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from rendezo r left join szindarab sz on r.rid = sz.rendezo";
		try {
			s = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				atm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo,rid,nev,szulido,lak,magassag+" cm"});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return atm;
		
	}
	public int Identification(String name, String pswd) {
		Connect();
		int pc = -1;
		String sql = "select count(*) pc from user where name='"+name+"' and pswd='"+pswd+"';";
		try {
			s = conn.createStatement();
			rs=s.executeQuery(sql);
			while(rs.next()) {
				pc=rs.getInt("pc");
			}
			rs.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
		return pc;
	}
	
	public RenTM ReadAllDataRend() {
		Object rentmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magass�g"};
		RenTM rentm = new RenTM(rentmn, 0);
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		String sql = "Select * from rendezo";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				rentm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return rentm;
	}
	
	public SzinTM ReadAllDataSzin() {
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		SzinTM stm = new SzinTM(szintmn,0);
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				stm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return stm;
	}
	
	public void DropTable(String name) {
		SM("Deleting table...");
		try {
			s = conn.createStatement();
			String sql = "Drop table " + name;
			s.executeUpdate(sql);
			SM("Done");
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void CreateTable(String name) {
		SM("Creating table...");
		try {
			s = conn.createStatement();
			String sql = "Create table "+ name +
						" (szid integer primary key not null, " +
						"cim varchar(255), " +
						"mikor date, " +
						"ar integer, " +
						"jatekido integer, " +
						"rendezo integer, " +
						"foreign key (rendezo) references rendezo(rid))";
			
			s.executeUpdate(sql);
			SM("Done");
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void ReadAllTable() {
		try {
			DatabaseMetaData md = conn.getMetaData();
			rs = md.getTables(null, null, "%", null);
			while(rs.next()) {
				System.out.println(rs.getString(3));
			}
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void Connect() {
		try {
			//jdbc:sqlite:C:/Users/dani5/AppData/Local/VirtualStore/Program Files/SQLite/elsobeadandodb.db
			String url = "jdbc:sqlite:src/elsobeadandodb.db";
			conn = DriverManager.getConnection(url);
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}
	
	public void DisConnect() {
		try {
			conn.close();
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}
	
	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
			SM("Sikeres regisztr�ci�!");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!"+e.getMessage());
		}
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 1);
	}
	public void SM(String msg,int tipus) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", tipus);
	}
	public void InsertSzin(String szid,String cim,String mikor,String ar,String jatekido,String rendezo) {
		
		String sql = "insert into szindarab values ("+szid+", '"+cim+"', '"+mikor+"', "+ar+", "+jatekido+", "+ rendezo +")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: "+e.getMessage());
		}
	}
	
	public void InsertRen(String rid,String nev,String szulido,String lak,String magassag) {
		
		String sql = "insert into rendezo values ("+rid+", '"+nev+"', '"+szulido+"', '"+lak+"', "+magassag+")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: "+e.getMessage());
		}
	}
	
	public void UpdateSzin(String szid,String cim,String mikor,String ar,String jatekido,String rendezo) {
		String sql = "update szindarab set cim= '"+cim+"', mikor= '"+mikor+"', ar= "+ar+", jatekido= "+jatekido+", rendezo= "+rendezo+" where szid= "+szid;
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Update OK!");
		} catch (Exception e) {
			SM("JDBC Udpate: "+e.getMessage());
		}
	}
	
	public void UpdateRen(String rid,String nev,String szulido,String lak,String magassag) {
		String sql = "update rendezo set nev= '"+nev+"', szulido= '"+szulido+"', lak= '"+lak+"', magassag= "+magassag+" where rid= "+rid;
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Update OK!");
		} catch (Exception e) {
			SM("JDBC Udpate: "+e.getMessage());
		}
	}
	
	public void DeleteSzin(String szid) {
		String sql = "delete from szindarab where szid="+szid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}
	
	public void DeleteRen(String rid) {
		String sql = "delete from rendezo where rid="+rid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}
	
	public Szures1TM ReadDataSzures1(String varos) {
		Object s1tmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magass�g"};
		Szures1TM s1tm = new Szures1TM(s1tmn, 0);
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		int db=0;
		String sql = "Select * from rendezo where lak ='"+varos+"'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				s1tm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if(db==0) {
			rid = 0;
			nev = "Hib�s adat";
			szulido = "";
			lak = "";
			magassag= 0;
			s1tm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
		}
		return s1tm;
	}
	
	public Szures2TM ReadDataSzures2(String nev) {
		Object s2tmn[] = {"Jel","N�v","Elk�sz�tett darabok"};
		Szures2TM s2tm = new Szures2TM(s2tmn, 0);
		int count=0;
		String strnev;
		String sql = "Select r.nev,count(sz.szid) darabszam from rendezo r inner join szindarab sz on r.rid=sz.rendezo where r.nev = ?";
		try {
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, nev);
			rs=ps.executeQuery();
			conn.commit();
			while(rs.next()) {
				strnev = rs.getString("nev");
				count= rs.getInt("darabszam");
				s2tm.addRow(new Object[] {false,strnev,count});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s2tm;
	}
	
	public Szures3TM ReadDataSzures3(String nev2) {
		Object s3tmn[] = {"Jel","N�v","Leghosszabb darab"};
		Szures3TM s3tm = new Szures3TM(s3tmn, 0);
		String strnev2;
		int hossz=0;
		String sql = "Select r.nev,max(jatekido) leghosszabb from rendezo r inner join szindarab sz on r.rid=sz.rendezo where r.nev = ?";
		try {
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, nev2);
			rs=ps.executeQuery();
			conn.commit();
			while(rs.next()) {
				strnev2 = rs.getString("nev");
				hossz= rs.getInt("leghosszabb");
				s3tm.addRow(new Object[] {false,strnev2,hossz});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s3tm;
	}
	
	public Szures4TM ReadDataSzures4(int alsohatar, int felsohatar) {
		Object s4tmn[] = {"Jel","K��d","C�m","Mikor","�r","J�t�kid�","Rendez�"};
		Szures4TM s4tm = new Szures4TM(s4tmn, 0);
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab where jatekido between "+alsohatar+" and "+felsohatar;
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				s4tm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s4tm;
	}
	
	public Szures5TM ReadDataSzures5() {
		Object s5tmn[] = {"Jel","C�m","J�t�kid�"};
		Szures5TM s5tm = new Szures5TM(s5tmn, 0);
		String cim;
		int jatekido=0;
		String sql = "Select cim,jatekido from szindarab where jatekido > 60";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				cim = rs.getString("cim");
				jatekido= rs.getInt("jatekido");
				s5tm.addRow(new Object[] {false,cim,jatekido});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s5tm;
	}
	
	public Szures6TM ReadDataSzures6() {
		Object s6tmn[] = {"Jel","N�v"};
		Szures6TM s6tm = new Szures6TM(s6tmn, 0);
		String nev;
		int atlaghossz=0;
		//CREATE VIEW atlaghossz AS SELECT r.nev, AVG(sz.jatekido) mjatekido FROM rendezo r INNER JOIN szindarab sz ON r.rid = sz.rendezo GROUP BY r.nev
		String sql = "SELECT nev FROM atlaghossz WHERE mjatekido =(SELECT MAX(mjatekido) FROM atlaghossz)";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				nev = rs.getString("nev");
				s6tm.addRow(new Object[] {false,nev});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s6tm;
	}
	
	public void openFile(String txtName) {
		try {
			x = new Formatter(txtName);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	public void closeFile() {
		x.close();
	}
	public void addRecordsSzin() {
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				x.format(szid+";"+cim+";"+mikor+";"+ar+";"+jatekido+";"+rendezo+"\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void addRecordsRend() {
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		String sql = "Select * from rendezo";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				x.format(rid+";"+nev+";"+szulido+";"+lak+";"+magassag+"\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void addRecordsAll() {
		String nev="", szulido="", lak="", cim="", mikor="";
		int rid=0, magassag=0;
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from rendezo r left join szindarab sz on r.rid = sz.rendezo";
		try {
			s = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				x.format("K�d: "+szid+", C�m: "+cim+", Premier: "+mikor+", Jegy �r: "+ar+" Ft, J�t�kid�: "+jatekido+" perc, Rendez� k�d: "+rendezo+", N�v: "+nev+", Sz�let�si id�: "+szulido+", Lakhely: "+lak+", Magass�g: "+magassag+" cm\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	public void getTables() {
		 try {
			 int i=1;
			  DatabaseMetaData metaData = conn.getMetaData();
		      String[] types = {"TABLE"};
		      ResultSet tables = metaData.getTables(null, null, "%", types);
		      while (tables.next()) {
		         SM(i+". t�bla neve: "+tables.getString("TABLE_NAME"));
		         i++;
		      }
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void ReplaceDataSzin(String file) {
		String sql ="";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf=in.readLine();
			while(sf!=null) {
				String[] st=sf.split(";");
				sql = "replace into szindarab values("+st[0]+", '"+st[1]+"', '"+st[2]+"', "+st[3]+", "+st[4]+", "+st[5]+")";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok felt�lve");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: "+e.getMessage());
		}
	}
	
	public void ReplaceDataRend(String file) {
		String sql ="";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf=in.readLine();
			while(sf!=null) {
				String[] st=sf.split(";");
				sql = "replace into rendezo values("+st[0]+", '"+st[1]+"', '"+st[2]+"', '"+st[3]+"', "+st[4]+")";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok felt�lve");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: "+e.getMessage());
		}
	}

	public ArrayList<String> readRid() {
		String sql = "Select rid from rendezo";
		ArrayList<String> ridStr = new ArrayList<String>();
		ridStr.add("V�lassz!");
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				ridStr.add(rs.getString("rid"));
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return ridStr;
	}
	
	public RenTM CsvReaderRen() {
		Object rentmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magass�g"};
		RenTM rentm = new RenTM(rentmn, 0);
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				rentm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
				s=in.readLine();
			}
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
		}
		return rentm;
	}
	
	public SzinTM CsvReaderSzin() {
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		SzinTM stm = new SzinTM(szintmn,0);
		try {
			BufferedReader in = new BufferedReader(new FileReader("szindarab.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				stm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4], st[5]});
				s=in.readLine();
			}
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return stm;
	}
	
	public AllTM CSVReaderAll() {
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","N�v","Sz�let�si id�","V�ros","Magass�g"};
		AllTM atm = new AllTM(alltmn, 0);
		try {
			BufferedReader in1 = new BufferedReader(new FileReader("rendezo.csv"));
			String s1 = in1.readLine();
			BufferedReader in2 = new BufferedReader(new FileReader("szindarab.csv"));
			String s2 = in2.readLine();
			while(s1!=null && s2!=null) {
				String[] st1 = s1.split(";");
				String[] st2 = s2.split(";");
				atm.addRow(new Object[] {false, st2[0], st2[1], st2[2], st2[3], st2[4], st2[5], st1[1], st1[2], st1[3], st1[4]});
				s1=in1.readLine();
				s2=in2.readLine();
			}
		} catch (Exception e) {
			SM("CSVREeader: " + e.getMessage());
		}
		return atm;
	}
	
	public void CSVWriteToTXTSzin() {
		try {
			BufferedReader in = new BufferedReader(new FileReader("szindarab.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				x.format(st[0]+";"+ st[1]+";"+ st[2]+";"+ st[3]+";"+ st[4]+";"+st[5]+"\n");
				s=in.readLine();
			}
			in.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void CSVWriteToTXTRen() {
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				x.format(st[0]+";"+ st[1]+";"+ st[2]+";"+ st[3]+";"+ st[4]+"\n");
				s=in.readLine();
			}
			in.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void CSVInsertSzin(String kod,String nev, String mikor,String ar,String jatekido,String rendezo) {
		String x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("szindarab.csv",true));
			out.println(kod+x+nev+x+mikor+x+ar+x+jatekido+x+rendezo);
			out.close();
			SM("Felvitel OK",1);
		} catch (IOException e) {
			SM("CsvWriter: " + e.getMessage());
		}
	}
	public void CSVInsertRen(String kod,String nev, String szulido,String lak,String magassag) {
		String x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rendezo.csv",true));
			out.println(kod+x+nev+x+szulido+x+lak+x+magassag);
			out.close();
			SM("Felvitel OK",1);
		} catch (IOException e) {
			SM("CsvWriter: " + e.getMessage());
		}
	}
	
	public ArrayList<String> CSVReadRenKod() {
		ArrayList<String> ridStr = new ArrayList<String>();
		ridStr.add("V�lassz!");
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				ridStr.add(st[0]);
				s = in.readLine();
			}
			in.close();
		} catch (IOException e) {
			SM(e.getMessage());
		}
		return ridStr;
	}
	
	public void CSVDelSzin(SzinTM stm) {
		String x = ";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("szindarab.csv"));
			for (int i = 0; i < stm.getRowCount(); i++) {
				String kod=stm.getValueAt(i, 1).toString();
				String cim=stm.getValueAt(i, 2).toString();
				String mikor=stm.getValueAt(i, 3).toString();
				String ar=stm.getValueAt(i, 4).toString();
				String jatekido=stm.getValueAt(i, 5).toString();
				String rendezo=stm.getValueAt(i, 6).toString();
				out.println(kod+x+cim+x+mikor+x+ar+x+jatekido+x+rendezo);
			}
			out.close();
		} catch (IOException e) {
			SM("Delete: "+e.getMessage());
		}
	}
	
	public void CSVDelRen(RenTM rentm) {
		String x = ";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rendezo.csv"));
			for (int i = 0; i < rentm.getRowCount(); i++) {
				String kod=rentm.getValueAt(i, 1).toString();
				String nev=rentm.getValueAt(i, 2).toString();
				String szulido=rentm.getValueAt(i, 3).toString();
				String lak=rentm.getValueAt(i, 4).toString();
				String magassag=rentm.getValueAt(i, 5).toString();
				out.println(kod+x+nev+x+szulido+x+lak+x+magassag);
			}
			out.close();
		} catch (IOException e) {
			SM("Delete: "+e.getMessage());
		}
	}
	public void CSVModSzin(String kod,String cim,String mikor,String ar,String jatekido,String rendezo,SzinTM stm, int jel) {
			if(c.filled(kod)) stm.setValueAt(kod, jel, 1);
			if(c.filled(cim)) stm.setValueAt(cim, jel, 2);
			if(c.filled(mikor)) stm.setValueAt(mikor, jel, 3);
			if(c.filled(ar)) stm.setValueAt(ar, jel, 4);
			if(c.filled(jatekido)) stm.setValueAt(jatekido, jel, 5);
			if(c.filled(rendezo)) stm.setValueAt(rendezo, jel, 6);
			this.CSVDelSzin(stm);
	}
	
	public void CSVModRen(String kod,String nev,String szulido,String lak,String magassag,RenTM rentm, int jel) {
		if(c.filled(kod)) rentm.setValueAt(kod, jel, 1);
		if(c.filled(nev)) rentm.setValueAt(nev, jel, 2);
		if(c.filled(szulido)) rentm.setValueAt(szulido, jel, 3);
		if(c.filled(lak)) rentm.setValueAt(lak, jel, 4);
		if(c.filled(magassag)) rentm.setValueAt(magassag, jel, 5);
		this.CSVDelRen(rentm);
	}
	
	public void CSVFillFromTxtSzin(SzinTM stm) {
		String kod,cim,mikor,ar,jatekido,rendezo,x=";";
		try {
			BufferedReader in = new BufferedReader(new FileReader("szindarab.txt"));
			PrintStream out = new PrintStream(new FileOutputStream("szindarab.csv"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				cim=st[1];
				mikor=st[2];
				ar=st[3];
				jatekido=st[4];
				rendezo=st[5];
				out.println(kod+x+cim+x+mikor+x+ar+x+jatekido+x+rendezo);
				s=in.readLine();
			}
			SM("Felvitel OK",1);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void CSVFillFromTxtRen(RenTM rentm) {
		String kod,nev,szulido,lak,magassag,x=";";
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.txt"));
			PrintStream out = new PrintStream(new FileOutputStream("rendezo.csv"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				nev=st[1];
				szulido=st[2];
				lak=st[3];
				magassag=st[4];
				out.println(kod+x+nev+x+szulido+x+lak+x+magassag);
				s=in.readLine();
			}
			SM("Felvitel OK",1);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public ErrSzinTM CSVsearchErrorsSzin() {
		Object errszintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		ErrSzinTM estm = new ErrSzinTM(errszintmn,0);
		try {
			int db=0;
			BufferedReader in = new BufferedReader(new FileReader("szindarab.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				boolean ok = false;
				if(c.filled(st[0]) && c.filled(st[1]) && c.filled(st[2]) && c.filled(st[3]) && c.filled(st[4]) && c.filled(st[5]) && c.goodDate(st[2]) && c.goodInt(st[0]) && c.goodInt(st[3]) && c.goodInt(st[4]) && c.goodInt(st[5]))
						ok = true;
				if(!ok) {
					estm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4], st[5]});
					db++;
				}
				s=in.readLine();
			}
			SM(db + " darab hib�t tal�tam a szindarab.csv-ben");
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return estm;
	}
	
	public ErrRenTM CSVsearchErrorsRen() {
		Object errrentmn[] = {"Jel","K�d","N�v","Sz�let�si id�","Lakhely","Magass�g"};
		ErrRenTM ertm = new ErrRenTM(errrentmn,0);
		try {
			int db=0;
			BufferedReader in = new BufferedReader(new FileReader("rendezo.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				boolean ok = false;
				if(c.filled(st[0]) && c.filled(st[1]) && c.filled(st[2]) && c.filled(st[3]) && c.filled(st[4]) && c.goodDate(st[2]) && c.goodInt(st[0]) && c.goodInt(st[4]))
						ok = true;
				if(!ok) {
					ertm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
					db++;
				}
				s=in.readLine();
			}
			SM(db + " darab hib�t tal�tam a rendezo.csv-ben");
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return ertm;
	}
	
	public void WriteToTXTErrSzin(ErrSzinTM estm) {
		String kod,cim,mikor,ar,jatekido,rendezo,x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("szindarabErr.txt"));
			for (int i = 0; i < estm.getRowCount(); i++) {
				kod=estm.getValueAt(i, 1).toString();
				cim=estm.getValueAt(i, 2).toString();
				mikor=estm.getValueAt(i, 3).toString();
				ar=estm.getValueAt(i, 4).toString();
				jatekido=estm.getValueAt(i, 5).toString();
				rendezo=estm.getValueAt(i, 6).toString();
				out.println(kod+x+cim+x+mikor+x+ar+x+jatekido+x+rendezo);
			}
			out.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void WriteToTXTErrRen(ErrRenTM ertm) {
		String kod,nev,szulido,lak,magassag,x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rendezoErr.txt"));
			for (int i = 0; i < ertm.getRowCount(); i++) {
				kod=ertm.getValueAt(i, 1).toString();
				nev=ertm.getValueAt(i, 2).toString();
				szulido=ertm.getValueAt(i, 3).toString();
				lak=ertm.getValueAt(i, 4).toString();
				magassag=ertm.getValueAt(i, 5).toString();
				out.println(kod+x+nev+x+szulido+x+lak+x+magassag);
			}
			out.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONWriteSzin() {
		JSONObject obj = new JSONObject();
		JSONArray listOfCodes = new JSONArray();
		JSONArray listOfTitles = new JSONArray();
		JSONArray listOfDates = new JSONArray();
		JSONArray listOfPrices = new JSONArray();
		JSONArray listOfLenght = new JSONArray();
		JSONArray listOfDirectors = new JSONArray();
		
		try {
			BufferedReader in = new BufferedReader(new FileReader("szindarab.txt"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				listOfCodes.add(st[0]);
				listOfTitles.add(st[1]);
				listOfDates.add(st[2]);
				listOfPrices.add(st[3]);
				listOfLenght.add(st[4]);
				listOfDirectors.add(st[5]);
				s=in.readLine();
			}
			obj.put("kodok", listOfCodes);
			obj.put("cimek", listOfTitles);
			obj.put("mikor", listOfDates);
			obj.put("ar", listOfPrices);
			obj.put("jatekido", listOfLenght);
			obj.put("rendezo", listOfDirectors);

			FileWriter file = new FileWriter("szindarab.json");
			file.write(obj.toString());
			file.flush();
			SM("Bet�lt�s OK!");
		} catch (IOException e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONWriteRen() {
		JSONObject obj = new JSONObject();
		JSONArray listOfCodes = new JSONArray();
		JSONArray listOfNames = new JSONArray();
		JSONArray listOfBirth = new JSONArray();
		JSONArray listOfHomes = new JSONArray();
		JSONArray listOfHeight = new JSONArray();
		
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.txt"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				listOfCodes.add(st[0]);
				listOfNames.add(st[1]);
				listOfBirth.add(st[2]);
				listOfHomes.add(st[3]);
				listOfHeight.add(st[4]);
				s=in.readLine();
			}
			obj.put("kodok", listOfCodes);
			obj.put("nevek", listOfNames);
			obj.put("szulidok", listOfBirth);
			obj.put("lakok", listOfHomes);
			obj.put("magassagok", listOfHeight);

			FileWriter file = new FileWriter("rendezo.json");
			file.write(obj.toString());
			file.flush();
			SM("Bet�lt�s OK!");
		} catch (IOException e) {
			SM(e.getMessage());
		}
	}
	
	public RenTM JSONReadRen() {
		Object rentmn[] = {"Jel","K�d","N�v","Sz�let�si id�","Lakhely","Magass�g"};
		RenTM rtm = new RenTM(rentmn,0);
		JSONParser parser = new JSONParser();
		int i=0;
		try {
			Object obj = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject = (JSONObject) obj;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfNames = (JSONArray) jsonObject.get("nevek");
			JSONArray listOfBirth = (JSONArray) jsonObject.get("szulidok");
			JSONArray listOfHomes = (JSONArray) jsonObject.get("lakok");
			JSONArray listOfHeight = (JSONArray) jsonObject.get("magassagok");
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				rtm.addRow(new Object[] {false, listOfCodes.get(i), listOfNames.get(i), listOfBirth.get(i), listOfHomes.get(i), listOfHeight.get(i)});
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return rtm;
	}
	
	public SzinTM JSONReadSzin() {
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		SzinTM stm = new SzinTM(szintmn,0);
		JSONParser parser = new JSONParser();
		int i=0;
		try {
			Object obj = parser.parse(new FileReader("szindarab.json"));
			JSONObject jsonObject = (JSONObject) obj;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfTitles = (JSONArray) jsonObject.get("cimek");
			JSONArray listOfDates = (JSONArray) jsonObject.get("mikor");
			JSONArray listOfPrices = (JSONArray) jsonObject.get("ar");
			JSONArray listOfLenght = (JSONArray) jsonObject.get("jatekido");
			JSONArray listOfDirectors = (JSONArray) jsonObject.get("rendezo");
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				stm.addRow(new Object[] {false, listOfCodes.get(i), listOfTitles.get(i), listOfDates.get(i), listOfPrices.get(i), listOfLenght.get(i), listOfDirectors.get(i)});
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return stm;
	}
	
	public AllTM JSONReadAll() {
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","N�v","Sz�let�si id�","V�ros","Magass�g"};
		AllTM atm = new AllTM(alltmn, 0);
		JSONParser parser = new JSONParser();
		int i = 0;
		try {
			Object obj1 = parser.parse(new FileReader("szindarab.json"));
			Object obj2 = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject1 = (JSONObject) obj1;
			JSONObject jsonObject2 = (JSONObject) obj2;
			
			JSONArray listOfCodes1 = (JSONArray) jsonObject1.get("kodok");
			JSONArray listOfTitles = (JSONArray) jsonObject1.get("cimek");
			JSONArray listOfDates = (JSONArray) jsonObject1.get("mikor");
			JSONArray listOfPrices = (JSONArray) jsonObject1.get("ar");
			JSONArray listOfLenght = (JSONArray) jsonObject1.get("jatekido");
			JSONArray listOfDirectors = (JSONArray) jsonObject1.get("rendezo");
			JSONArray listOfCodes2 = (JSONArray) jsonObject2.get("kodok");
			JSONArray listOfNames = (JSONArray) jsonObject2.get("nevek");
			JSONArray listOfBirth = (JSONArray) jsonObject2.get("szulidok");
			JSONArray listOfHomes = (JSONArray) jsonObject2.get("lakok");
			JSONArray listOfHeight = (JSONArray) jsonObject2.get("magassagok");
			Iterator<String> iteratorCodes = listOfCodes1.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes1.size()) {
				atm.addRow(new Object[] {false,  listOfCodes1.get(i), listOfTitles.get(i), listOfDates.get(i), listOfPrices.get(i), listOfLenght.get(i), listOfDirectors.get(i), listOfNames.get(i), listOfBirth.get(i), listOfHomes.get(i), listOfHeight.get(i)});
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return atm;
	}
	
	public void JSONDelSzin(SzinTM stm) {
		JSONObject obj = new JSONObject();
		JSONArray listOfCodes = new JSONArray();
		JSONArray listOfTitles = new JSONArray();
		JSONArray listOfDates = new JSONArray();
		JSONArray listOfPrices = new JSONArray();
		JSONArray listOfLenght = new JSONArray();
		JSONArray listOfDirectors = new JSONArray();
		
		try {
			for (int i = 0; i < stm.getRowCount(); i++) {
				String kod=stm.getValueAt(i, 1).toString();
				String cim=stm.getValueAt(i, 2).toString();
				String mikor=stm.getValueAt(i, 3).toString();
				String ar=stm.getValueAt(i, 4).toString();
				String jatekido=stm.getValueAt(i, 5).toString();
				String rendezo=stm.getValueAt(i, 6).toString();
				listOfCodes.add(kod);
				listOfTitles.add(cim);
				listOfDates.add(mikor);
				listOfPrices.add(ar);
				listOfLenght.add(jatekido);
				listOfDirectors.add(rendezo);
			}
			obj.put("kodok", listOfCodes);
			obj.put("cimek", listOfTitles);
			obj.put("mikor", listOfDates);
			obj.put("ar", listOfPrices);
			obj.put("jatekido", listOfLenght);
			obj.put("rendezo", listOfDirectors);

			FileWriter file = new FileWriter("szindarab.json");
			file.write(obj.toString());
			file.flush();
		} catch (IOException e) {
			SM("Delete: "+e.getMessage());
		}
	}
	
	public void JSONDelRen(RenTM rentm) {
		JSONObject obj = new JSONObject();
		JSONArray listOfCodes = new JSONArray();
		JSONArray listOfNames = new JSONArray();
		JSONArray listOfBirth = new JSONArray();
		JSONArray listOfHomes = new JSONArray();
		JSONArray listOfHeight = new JSONArray();
		
		try {
			for (int i = 0; i < rentm.getRowCount(); i++) {
				String kod=rentm.getValueAt(i, 1).toString();
				String nev=rentm.getValueAt(i, 2).toString();
				String szulido=rentm.getValueAt(i, 3).toString();
				String lak=rentm.getValueAt(i, 4).toString();
				String magassag=rentm.getValueAt(i, 5).toString();
				listOfCodes.add(kod);
				listOfNames.add(nev);
				listOfBirth.add(szulido);
				listOfHomes.add(lak);
				listOfHeight.add(magassag);
			}
			
			obj.put("kodok", listOfCodes);
			obj.put("nevek", listOfNames);
			obj.put("szulidok", listOfBirth);
			obj.put("lakok", listOfHomes);
			obj.put("magassagok", listOfHeight);

			FileWriter file = new FileWriter("rendezo.json");
			file.write(obj.toString());
			file.flush();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONModSzin(String kod,String cim,String mikor,String ar,String jatekido,String rendezo,SzinTM stm, int jel) {
		if(c.filled(kod)) stm.setValueAt(kod, jel, 1);
		if(c.filled(cim)) stm.setValueAt(cim, jel, 2);
		if(c.filled(mikor)) stm.setValueAt(mikor, jel, 3);
		if(c.filled(ar)) stm.setValueAt(ar, jel, 4);
		if(c.filled(jatekido)) stm.setValueAt(jatekido, jel, 5);
		if(c.filled(rendezo)) stm.setValueAt(rendezo, jel, 6);
		this.JSONDelSzin(stm);
	}
	
	public ArrayList<String> JSONReadRenKod(){
		ArrayList<String> ridStr = new ArrayList<String>();
		ridStr.add("V�lassz!");
		JSONParser parser = new JSONParser();
		int i=0;
		try {
			Object obj = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				ridStr.add((String) listOfCodes.get(i));
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return ridStr;
	}
	
	public void JSONModRen(String kod,String nev,String szulido,String lak,String magassag,RenTM rentm, int jel) {
		if(c.filled(kod)) rentm.setValueAt(kod, jel, 1);
		if(c.filled(nev)) rentm.setValueAt(nev, jel, 2);
		if(c.filled(szulido)) rentm.setValueAt(szulido, jel, 3);
		if(c.filled(lak)) rentm.setValueAt(lak, jel, 4);
		if(c.filled(magassag)) rentm.setValueAt(magassag, jel, 5);
		this.JSONDelRen(rentm);
	}
	
	public void JSONWriteToTXTSzin() {
		JSONParser parser = new JSONParser();
		int i = 0;
		try {
			Object obj = parser.parse(new FileReader("szindarab.json"));
			JSONObject jsonObject = (JSONObject) obj;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfTitles = (JSONArray) jsonObject.get("cimek");
			JSONArray listOfDates = (JSONArray) jsonObject.get("mikor");
			JSONArray listOfPrices = (JSONArray) jsonObject.get("ar");
			JSONArray listOfLenght = (JSONArray) jsonObject.get("jatekido");
			JSONArray listOfDirectors = (JSONArray) jsonObject.get("rendezo");
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				x.format(listOfCodes.get(i)+";"+ listOfTitles.get(i)+";"+listOfDates.get(i)+";"+listOfPrices.get(i)+";"+listOfLenght.get(i)+";"+listOfDirectors.get(i)+"\n");
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONWriteToTXTRen() {
		JSONParser parser = new JSONParser();
		int i = 0;
		try {
			Object obj = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject = (JSONObject) obj;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfNames = (JSONArray) jsonObject.get("nevek");
			JSONArray listOfBirth = (JSONArray) jsonObject.get("szulidok");
			JSONArray listOfHomes = (JSONArray) jsonObject.get("lakok");
			JSONArray listOfHeight = (JSONArray) jsonObject.get("magassagok");
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				x.format(listOfCodes.get(i)+";"+ listOfNames.get(i)+";"+listOfBirth.get(i)+";"+listOfHomes.get(i)+";"+listOfHeight.get(i)+"\n");
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONInsertSzin(String kod,String nev, String mikor,String ar,String jatekido,String rendezo) {
		JSONParser parser = new JSONParser();
		try {
			Object obj1 = parser.parse(new FileReader("szindarab.json"));
			JSONObject jsonObject = (JSONObject) obj1;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfTitles = (JSONArray) jsonObject.get("cimek");
			JSONArray listOfDates = (JSONArray) jsonObject.get("mikor");
			JSONArray listOfPrices = (JSONArray) jsonObject.get("ar");
			JSONArray listOfLenght = (JSONArray) jsonObject.get("jatekido");
			JSONArray listOfDirectors = (JSONArray) jsonObject.get("rendezo");
			
			listOfCodes.add(kod);
			listOfTitles.add(nev);
			listOfDates.add(mikor);
			listOfPrices.add(ar);
			listOfLenght.add(jatekido);
			listOfDirectors.add(rendezo);
			
			JSONObject obj = new JSONObject();
					
			obj.put("kodok", listOfCodes);
			obj.put("cimek", listOfTitles);
			obj.put("mikor", listOfDates);
			obj.put("ar", listOfPrices);
			obj.put("jatekido", listOfLenght);
			obj.put("rendezo", listOfDirectors);
			
			
			FileWriter file = new FileWriter("szindarab.json");
			file.write(obj.toString());
			file.flush();
			SM("Insert OK!");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void JSONInsertRen(String kod,String nev, String szulido,String lak,String magassag) {
		JSONParser parser = new JSONParser();
		try {
			Object obj1 = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject = (JSONObject) obj1;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfNames = (JSONArray) jsonObject.get("nevek");
			JSONArray listOfBirth = (JSONArray) jsonObject.get("szulidok");
			JSONArray listOfHomes = (JSONArray) jsonObject.get("lakok");
			JSONArray listOfHeight = (JSONArray) jsonObject.get("magassagok");
			
			listOfCodes.add(kod);
			listOfNames.add(nev);
			listOfBirth.add(szulido);
			listOfHomes.add(lak);
			listOfHeight.add(magassag);
			
			JSONObject obj = new JSONObject();
					
			obj.put("kodok", listOfCodes);
			obj.put("nevek", listOfNames);
			obj.put("szulidok", listOfBirth);
			obj.put("lakok", listOfHomes);
			obj.put("magassagok", listOfHeight);
			
			
			FileWriter file = new FileWriter("rendezo.json");
			file.write(obj.toString());
			file.flush();
			SM("Insert OK!");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public ErrRenTM JSONsearchErrRen() {
		Object errrentmn[] = {"Jel","K�d","N�v","Sz�let�si id�","Lakhely","Magassg�g"};
		ErrRenTM ertm = new ErrRenTM(errrentmn,0);
		JSONParser parser = new JSONParser();
		int i = 0;
		boolean ok = false;
		int db = 0;
		try {
			Object obj1 = parser.parse(new FileReader("rendezo.json"));
			JSONObject jsonObject = (JSONObject) obj1;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfNames = (JSONArray) jsonObject.get("nevek");
			JSONArray listOfBirth = (JSONArray) jsonObject.get("szulidok");
			JSONArray listOfHomes = (JSONArray) jsonObject.get("lakok");
			JSONArray listOfHeight = (JSONArray) jsonObject.get("magassagok");
			String[] kodok = new String[listOfCodes.size()], nevek = new String[listOfCodes.size()], szulido=new String[listOfCodes.size()],lak=new String[listOfCodes.size()],magassag=new String[listOfCodes.size()];
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				ok = false;
				kodok[i] = listOfCodes.get(i).toString();
				nevek[i] = listOfNames.get(i).toString();
				szulido[i] = listOfBirth.get(i).toString();
				lak[i] = listOfHomes.get(i).toString();
				magassag[i] = listOfHeight.get(i).toString();
				if(c.filled(kodok[i])&&c.filled(nevek[i])&&c.filled(szulido[i])&&c.filled(lak[i])&&c.filled(magassag[i])&&c.goodInt(kodok[i])&&c.goodInt(magassag[i])&&c.goodDate(szulido[i])) {
					ok=true;
				}
				if(!ok) {
					ertm.addRow(new Object[] {false, listOfCodes.get(i), listOfNames.get(i), listOfBirth.get(i), listOfHomes.get(i), listOfHeight.get(i)});
					db++;
				}
				i++;
			}
			SM(db+" darab hib�t tal�ltam a rendez�kben");
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return ertm;
	}
	
	public ErrSzinTM JSONsearchErrSzin() {
		Object errszintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		ErrSzinTM estm = new ErrSzinTM(errszintmn,0);
		JSONParser parser = new JSONParser();
		int i = 0;
		boolean ok = false;
		int db = 0;
		try {
			Object obj1 = parser.parse(new FileReader("szindarab.json"));
			JSONObject jsonObject = (JSONObject) obj1;
			
			JSONArray listOfCodes = (JSONArray) jsonObject.get("kodok");
			JSONArray listOfTitles = (JSONArray) jsonObject.get("cimek");
			JSONArray listOfDates = (JSONArray) jsonObject.get("mikor");
			JSONArray listOfPrices = (JSONArray) jsonObject.get("ar");
			JSONArray listOfLenght = (JSONArray) jsonObject.get("jatekido");
			JSONArray listOfDirectors = (JSONArray) jsonObject.get("rendezo");
			String[] kodok = new String[listOfCodes.size()], cimek = new String[listOfCodes.size()], mikor=new String[listOfCodes.size()],arak=new String[listOfCodes.size()],jatekidok=new String[listOfCodes.size()],rendezok=new String[listOfCodes.size()];
			Iterator<String> iteratorCodes = listOfCodes.iterator();
			while(iteratorCodes.hasNext()&&i<listOfCodes.size()) {
				ok = false;
				kodok[i] = listOfCodes.get(i).toString();
				cimek[i] = listOfTitles.get(i).toString();
				mikor[i] = listOfDates.get(i).toString();
				arak[i] = listOfPrices.get(i).toString();
				jatekidok[i] = listOfLenght.get(i).toString();
				rendezok[i] = listOfDirectors.get(i).toString();
				if(c.filled(kodok[i])&&c.filled(cimek[i])&&c.filled(mikor[i])&&c.filled(arak[i])&&c.filled(jatekidok[i])&&c.filled(rendezok[i]) &&c.goodInt(kodok[i])&&c.goodInt(arak[i])&&c.goodInt(rendezok[i])&&c.goodDate(mikor[i])) {
					ok=true;
				}
				if(!ok) {
					estm.addRow(new Object[] {false, listOfCodes.get(i), listOfTitles.get(i), listOfDates.get(i), listOfPrices.get(i), listOfLenght.get(i), listOfDirectors.get(i)});
					db++;
				}
				i++;
			}
			SM(db+" darab hib�t tal�ltam a szindarabokban");
		} catch (Exception e) {
			SM(e.getMessage());
		}
		return estm;
	}
	
	public void DataWriteToPdf() {
		try {
			Rectangle pageSize = new Rectangle(1000, 720);
			pageSize.setBackgroundColor(new BaseColor(0x03, 0xFC, 0xF4));
			Document document = new Document(pageSize);
			PdfWriter.getInstance(document, new FileOutputStream("rendezok_szindarabok.pdf"));

			document.open();
			document.addTitle("Rendez�k �s Sz�ndarabok");
			PdfPTable rendezo = new PdfPTable(5);
			addTableHeaderRen(rendezo);
			addRowsRen(rendezo);
			PdfPTable szindarab = new PdfPTable(6);
			addTableHeaderSzin(szindarab);
			addRowsSzin(szindarab);
			
			document.add(rendezo);
			document.add(szindarab);
			document.close();
			SM("Felvitel OK");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	private void addTableHeaderRen(PdfPTable table) {
	    Stream.of("K�d:", "N�v", "Sz�l. Id�", "Lakhely","Magass�g")
	      .forEach(columnTitle -> {
	        PdfPCell header = new PdfPCell();
	        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        header.setBorderWidth(2);
	        header.setPhrase(new Phrase(columnTitle));
	        table.addCell(header);
	    });
	}
	
	private void addTableHeaderSzin(PdfPTable table) {
	    Stream.of("K�d:", "C�m", "Premier", "Jegy �r","J�t�kid�", "Rendez� sz�ma")
	      .forEach(columnTitle -> {
	        PdfPCell header = new PdfPCell();
	        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        header.setBorderWidth(2);
	        header.setPhrase(new Phrase(columnTitle));
	        table.addCell(header);
	    });
	}
	
	private void addRowsSzin(PdfPTable table) {
		String kod,cim,mikor,ar,jatekido,rendezo;
		try {
			BufferedReader in = new BufferedReader(new FileReader("szindarab.txt"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				cim=st[1];
				mikor=st[2];
				ar=st[3];
				jatekido=st[4];
				rendezo=st[5];
				table.addCell(kod);
				table.addCell(cim);
				table.addCell(mikor);
				table.addCell(ar);
				table.addCell(jatekido);
				table.addCell(rendezo);
				s=in.readLine();
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	private void addRowsRen(PdfPTable table) {
		String kod,nev,szulido,lak,magassag;
		try {
			BufferedReader in = new BufferedReader(new FileReader("rendezo.txt"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				nev=st[1];
				szulido=st[2];
				lak=st[3];
				magassag=st[4];
				table.addCell(kod);
				table.addCell(nev);
				table.addCell(szulido);
				table.addCell(lak);
				table.addCell(magassag);
				s=in.readLine();
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
}