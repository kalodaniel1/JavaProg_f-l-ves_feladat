package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JComboBox;

public class ModSzin extends JDialog {
	DbMethods dbm = new DbMethods();
	private final JPanel contentPanel = new JPanel();
	private JTextField szid;
	private JTextField cim;
	private JTextField mikor;
	private JTextField ar;
	private JTextField jatekido;
	private JTextField rendezo;
	private JTextField cim2;
	private JTextField mikor2;
	private JTextField ar2;
	private JTextField jatekido2;
	private JComboBox rendezo2;
	private ArrayList<String> ridStr;
	private Checker c = new Checker();
	
	public ModSzin(JDialog d, String beszid,String becim,String bemikor,String bear,String bejatekido,String berendezo, int n, SzinTM stm, int jel) {
		super(d, "Adatok m�dos�t�sa", true);
		setBounds(100, 100, 468, 246);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("K\u00F3d:");
		lblNewLabel.setBounds(10, 14, 46, 14);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("C\u00EDm:");
		lblNewLabel_1.setBounds(10, 39, 56, 14);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mikort\u00F3l:");
		lblNewLabel_2.setBounds(10, 64, 73, 14);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Jegy \u00E1r:");
		lblNewLabel_3.setBounds(10, 89, 73, 14);
		contentPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("J\u00E1t\u00E9kid\u0151:");
		lblNewLabel_4.setBounds(10, 114, 86, 14);
		contentPanel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Rendez\u0151 ID:");
		lblNewLabel_5.setBounds(10, 139, 86, 14);
		contentPanel.add(lblNewLabel_5);
		
		szid = new JTextField(beszid);
		szid.setEditable(false);
		szid.setBounds(151, 14, 86, 20);
		contentPanel.add(szid);
		szid.setColumns(10);
		
		cim = new JTextField(becim);
		cim.setEditable(false);
		cim.setBounds(93, 39, 144, 20);
		contentPanel.add(cim);
		cim.setColumns(10);
		
		mikor = new JTextField(bemikor);
		mikor.setEditable(false);
		mikor.setBounds(103, 64, 134, 20);
		contentPanel.add(mikor);
		mikor.setColumns(10);
		
		ar = new JTextField(bear);
		ar.setEditable(false);
		ar.setBounds(151, 89, 86, 20);
		contentPanel.add(ar);
		ar.setColumns(10);
		
		jatekido = new JTextField(bejatekido);
		jatekido.setEditable(false);
		jatekido.setBounds(151, 114, 86, 20);
		contentPanel.add(jatekido);
		jatekido.setColumns(10);
		
		rendezo = new JTextField(berendezo);
		rendezo.setEditable(false);
		rendezo.setBounds(151, 139, 86, 20);
		contentPanel.add(rendezo);
		rendezo.setColumns(10);
		
		JButton btnMod = new JButton("M\u00F3dos\u00EDt");
		btnMod.setBackground(new Color(0, 191, 255));
		btnMod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(n==0) {
					dbm.Connect();
					dbm.UpdateSzin(RTF(szid), RTF2(cim2,cim),RTF2(mikor2,mikor), RTF2(ar2,ar), RTF2(jatekido2,jatekido), RTF3(rendezo2,rendezo));
					dbm.DisConnect();
					dispose();
				}
				else if(n==1) {
					if(modDataPc()>0) {
						dbm.CSVModSzin(RTF(szid), RTF2(cim2,cim),RTF2(mikor2,mikor), RTF2(ar2,ar), RTF2(jatekido2,jatekido), RTF3(rendezo2,rendezo), stm, jel);
						dispose();
					}
				}
				else if(n==2) {
					dbm.JSONModSzin(RTF(szid), RTF2(cim2,cim),RTF2(mikor2,mikor), RTF2(ar2,ar), RTF2(jatekido2,jatekido), RTF3(rendezo2,rendezo), stm, jel);
					dispose();
				}
			}
		});
		btnMod.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(0,191,255));
		    }
		});
		btnMod.setBounds(306, 173, 89, 23);
		contentPanel.add(btnMod);
		btnMod.setFont(new Font("Arial", Font.BOLD, 13));
		
		cim2 = new JTextField();
		cim2.setBounds(247, 39, 195, 20);
		contentPanel.add(cim2);
		cim2.setColumns(10);
		
		mikor2 = new JTextField();
		mikor2.setText("");
		mikor2.setBounds(247, 64, 134, 20);
		contentPanel.add(mikor2);
		mikor2.setColumns(10);
		
		ar2 = new JTextField();
		ar2.setBounds(247, 89, 86, 20);
		contentPanel.add(ar2);
		ar2.setColumns(10);
		
		jatekido2 = new JTextField();
		jatekido2.setText("");
		jatekido2.setBounds(247, 114, 86, 20);
		contentPanel.add(jatekido2);
		jatekido2.setColumns(10);
		
		if(n==0) {
			dbm.Connect();
			ridStr = dbm.readRid();
			dbm.DisConnect();
			Object[] real = ridStr.toArray();
			rendezo2 = new JComboBox(real);
		}
		else if(n==1) {
			ridStr = dbm.CSVReadRenKod();
			Object[] real = ridStr.toArray();
			rendezo2 = new JComboBox(real);
		}
		else if(n==2) {
			ridStr = dbm.JSONReadRenKod();
			Object[] real = ridStr.toArray();
			rendezo2 = new JComboBox(real);
		}
		rendezo2.setBounds(249, 139, 101, 27);
		contentPanel.add(rendezo2);
		
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	
	public String RTF2(JTextField jtf2, JTextField jtf) {
		if(jtf2.getText().length()==0)
			return jtf.getText();
		return jtf2.getText();
	}
	
	public String RTF3(JComboBox jcb, JTextField jtf) {
		if(jcb.getSelectedItem().toString().equals("V�lassz!"))
			return jtf.getText();
		return jcb.getSelectedItem().toString();
	}
	
	public int modDataPc() {
		int pc = 0;
		if(c.filled(szid)) pc++;
		if(c.filled(cim2)) pc++;
		if(c.filled(mikor2)) pc++;
		if(c.filled(ar2)) pc++;
		if(c.filled(jatekido2)) pc++;
		return pc;
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
