package db2_elso_beadando;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class RenList extends JDialog {
	private JTable table;
	private RenTM rentm;
	DbMethods dbm = new DbMethods();
	private Checker c = new Checker();

		public RenList(JFrame f, RenTM betm) {
			super(f,"Rendez�k list�ja", true);
			setUndecorated(true);
			getContentPane().setBackground(new Color(0, 255, 255));
			rentm = betm;
		setBounds(100, 100, 640, 377);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		
		JButton btnBezar = new JButton("Bez\u00E1r\u00E1s");
		btnBezar.setBackground(new Color(0, 191, 255));
		btnBezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0, 191, 255));
		    }
		});
		btnBezar.setBounds(518, 325, 112, 41);
		getContentPane().add(btnBezar);
		btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 620, 303);
		getContentPane().add(scrollPane);
		
		table = new JTable(rentm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 6; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1 || i==5) tc.setPreferredWidth(30);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		
		JButton btnMod = new JButton("M\u00F3dos\u00EDt\u00E1s");
		btnMod.setBackground(new Color(0, 191, 255));
		btnMod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0, jel=0, x=0;
				for (x = 0; x < rentm.getRowCount(); x++) 
					if((Boolean)rentm.getValueAt(x, 0)) {db++; jel=x;}
				if(db==0) SM("V�lasszon ki egy rekordot");
				if(db>1) SM("Maximum egy rekordot lehet kiv�lasztani");
				if(db==1) {
					if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
						ModRen mr = new ModRen(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5),0,rentm,jel);
						mr.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
						ModRen mr = new ModRen(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5),1,rentm,jel);
						mr.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
						ModRen mr = new ModRen(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5),2,rentm,jel);
						mr.setVisible(true);
					}
				}
			}
		});
		btnMod.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(0, 191, 255));
		    }
		});
		btnMod.setBounds(10, 325, 112, 41);
		getContentPane().add(btnMod);
		btnMod.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnTorol = new JButton("T\u00F6rl\u00E9s");
		btnTorol.setBackground(new Color(0, 191, 255));
		btnTorol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
					int db=0,jel=0,x=0;
					for (x = 0; x < rentm.getRowCount(); x++)
						if((Boolean)rentm.getValueAt(x, 0)) {db++; jel=x;}
					if(db==0) SM("Nincs kijel�lve semmi");
					if(db>1) SM("Egyszerre csak egy t�r�lhet�");
					if(db==1) {
						dbm.Connect();
						dbm.DeleteRen(RTM(jel,1));
						rentm.removeRow(jel);
						dbm.DisConnect();
					}
				}
				else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
					int db=0,jel=0,x=0;
					for (x = 0; x < rentm.getRowCount(); x++)
						if((Boolean)rentm.getValueAt(x, 0)) {db++; jel=x;}
					if(db==0) SM("Nincs kijel�lve semmi");
					if(db>1) SM("Egyszerre csak egy t�r�lhet�");
					if(db==1) {
						rentm.removeRow(jel);
						dbm.CSVDelRen(rentm);
						dispose();
						c.SM("A rekord t�r�lve", 1);
					}
				}
				else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
					int db=0,jel=0,x=0;
					for (x = 0; x < rentm.getRowCount(); x++)
						if((Boolean)rentm.getValueAt(x, 0)) {db++; jel=x;}
					if(db==0) SM("Nincs kijel�lve semmi");
					if(db>1) SM("Egyszerre csak egy t�r�lhet�");
					if(db==1) {
						rentm.removeRow(jel);
						dbm.JSONDelRen(rentm);
						dispose();
						c.SM("A rekord t�r�lve", 1);
					}
				}
			}
		});
		btnTorol.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnTorol.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnTorol.setBackground(new Color(0, 191, 255));
		    }
		});
		btnTorol.setBounds(132, 325, 108, 41);
		getContentPane().add(btnTorol);
		btnTorol.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnWriteToFile = new JButton("Ment\u00E9s");
		btnWriteToFile.setBackground(new Color(0, 191, 255));
		btnWriteToFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
						dbm.Connect();
						dbm.openFile("rendezo.txt");
						dbm.addRecordsRend();
						dbm.closeFile();
						dbm.DisConnect();
						SM("Sikeres ki�r�s! A file megtal�lhat� rendezo.txt n�ven");
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
						dbm.openFile("rendezo.txt");
						dbm.CSVWriteToTXTRen();
						dbm.closeFile();
						SM("Sikeres ki�r�s! A file megtal�lhat� rendezo.txt n�ven");
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
						dbm.openFile("rendezo.txt");
						dbm.JSONWriteToTXTRen();
						dbm.closeFile();
						SM("Sikeres ki�r�s! A file megtal�lhat� rendezo.txt n�ven");
					}
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnWriteToFile.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(0, 191, 255));
		    }
		});
		btnWriteToFile.setBounds(250, 325, 108, 41);
		getContentPane().add(btnWriteToFile);
		btnWriteToFile.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnBetolt = new JButton("Bet\u00F6lt\u00E9s");
		btnBetolt.setBackground(new Color(0, 191, 255));
		btnBetolt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
					dbm.ReplaceDataRend("rendezo.txt");
				}
				else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
					dbm.CSVFillFromTxtRen(rentm);
				}
				else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
					dbm.JSONWriteRen();
				}
			}
		});
		btnBetolt.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBetolt.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBetolt.setBackground(new Color(0, 191, 255));
		    }
		});
		btnBetolt.setBounds(368, 325, 108, 41);
		getContentPane().add(btnBetolt);
		btnBetolt.setFont(new Font("Arial", Font.BOLD, 13));
		TableRowSorter<RenTM> trs = (TableRowSorter<RenTM>)table.getRowSorter();
		trs.setSortable(0, false);
		

	}
		public String RTM(int row,int col) {
			return rentm.getValueAt(row, col).toString();
		}
		
		public void SM(String msg) {
			JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
		}
}
