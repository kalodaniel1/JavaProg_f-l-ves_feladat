package db2_elso_beadando;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.LayoutManager;

import javax.swing.border.LineBorder;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

public class ABKezeloProg extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DbMethods dbm = new DbMethods();
	private SzinTM stm;
	private RenTM rentm;
	private AllTM atm;
	private JPanel contentPane;
	private static Login login;
	private int posX=0,posY=0;
	
	public ABKezeloProg(ChooseType chooseType) {
		super("Kezd�lap");
		setUndecorated(true);
		setFont(new Font("Arial", Font.PLAIN, 12));
		setForeground(Color.GRAY);
		setBackground(Color.GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 575, 395);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new LineBorder(new Color(25, 25, 112), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
	
		//Ablak mozgat�sa
		this.addMouseListener(new MouseAdapter()
		{
		   public void mousePressed(MouseEvent e)
		   {
		      posX=e.getX();
		      posY=e.getY();
		   }
		});
		
		this.addMouseMotionListener(new MouseAdapter()
		{
		     public void mouseDragged(MouseEvent evt)
		     {	
				setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);	
		     }
		});
		
		JButton btnReg = new JButton("Driver Regisztr\u00E1l\u00E1sa");
		btnReg.setBackground(new Color(0, 191, 255));
		btnReg.setForeground(Color.BLACK);
		btnReg.setFont(new Font("Arial", Font.BOLD, 13));
		btnReg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Reg();
			}
		});
		btnReg.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnReg.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnReg.setBackground(new Color(0, 191, 255));
		    }
		});
		btnReg.setBounds(180, 156, 223, 62);
		contentPane.add(btnReg);
		
		JButton btnSzinLista = new JButton("Sz\u00EDndarabok list\u00E1ja");
		btnSzinLista.setBackground(new Color(0, 191, 255));
		btnSzinLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				stm = dbm.ReadAllDataSzin();
				dbm.DisConnect();
				SzinList sl = new SzinList(ABKezeloProg.this, stm);
				sl.setVisible(true);
			}
		});
		btnSzinLista.setBounds(10, 156, 160, 62);
		contentPane.add(btnSzinLista);
		btnSzinLista.setFont(new Font("Arial", Font.BOLD, 13));
		btnSzinLista.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzinLista.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzinLista.setBackground(new Color(0, 191, 255));
		    }
		});
		
		JButton btnRenLista = new JButton("Rendez\u0151k list\u00E1ja");
		btnRenLista.setBackground(new Color(0, 191, 255));
		btnRenLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				rentm = dbm.ReadAllDataRend();
				dbm.DisConnect();
				RenList rl = new RenList(ABKezeloProg.this, rentm);
				rl.setVisible(true);
			}
		});
		btnRenLista.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnRenLista.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnRenLista.setBackground(new Color(0, 191, 255));
		    }
		});
		btnRenLista.setBounds(416, 156, 149, 62);
		contentPane.add(btnRenLista);
		btnRenLista.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnUjAdat = new JButton("\u00DAj adatsor");
		btnUjAdat.setBackground(new Color(0, 191, 255));
		btnUjAdat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChooseInsert ci = new ChooseInsert(ABKezeloProg.this);
				ci.setVisible(true);
			}
		});
		btnUjAdat.setBounds(391, 314, 174, 62);
		contentPane.add(btnUjAdat);
		btnUjAdat.setFont(new Font("Arial", Font.PLAIN, 25));
		btnUjAdat.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnUjAdat.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnUjAdat.setBackground(new Color(0, 191, 255));
		    }
		});
		
		JButton btnAllList = new JButton("Minden adat kilist\u00E1z\u00E1sa");
		btnAllList.setBackground(new Color(0, 191, 255));
		btnAllList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				atm = dbm.ReadAllData();
				dbm.DisConnect();
				AllList al = new AllList(ABKezeloProg.this, atm);
				al.setVisible(true);
			}
		});
		btnAllList.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnAllList.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnAllList.setBackground(new Color(0, 191, 255));
		    }
		});
		btnAllList.setBounds(369, 241, 196, 62);
		contentPane.add(btnAllList);
		btnAllList.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnSzuro = new JButton("Sz\u0171r\u0151");
		btnSzuro.setForeground(new Color(0, 0, 0));
		btnSzuro.setBackground(new Color(0, 191, 255));
		btnSzuro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Szurok sz = new Szurok();
				sz.setVisible(true);
			}
		});
		btnSzuro.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzuro.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzuro.setBackground(new Color(0, 191, 255));
		    }
		});
		btnSzuro.setBounds(10, 314, 187, 62);
		contentPane.add(btnSzuro);
		btnSzuro.setFont(new Font("Arial", Font.PLAIN, 25));
		
		
		JButton btnTables = new JButton("T\u00E1bl\u00E1k");
		btnTables.setBackground(new Color(0, 191, 255));
		btnTables.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				dbm.getTables();
				dbm.DisConnect();
			}
		});
		btnTables.setBounds(207, 314, 174, 62);
		contentPane.add(btnTables);
		btnTables.setFont(new Font("Arial", Font.PLAIN, 25));
		btnTables.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnTables.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnTables.setBackground(new Color(0, 191, 255));
		    }
		});
		
		ImageIcon icon = new ImageIcon("logo.png");
		String logo = "src/logo.png";
		JLabel lblLogo = new JLabel(new ImageIcon(logo));
		lblLogo.setBounds(145, 11, 281, 134);
		contentPane.add(lblLogo);
		
		JLabel lblX = new JLabel("X");
		lblX.setFont(new Font("Arial", Font.BOLD, 13));
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblX.setForeground(new Color(255,0,0));
				
			}
			public void mouseExited(MouseEvent e) {
				lblX.setForeground(new Color(0,0,0));
			}
		});
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setBounds(545, 11, 20, 20);
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(JOptionPane.showConfirmDialog(null, "Ezzel visszal�p a form�tum v�laszt�shoz. Biztos?", "Biztos?", JOptionPane.YES_NO_OPTION)==0) {
					ChooseType ct = new ChooseType(null);
					ct.setVisible(true);
					dispose();
				}
			}
		});
		contentPane.add(lblX);
		
		JButton btnPdf = new JButton("Adatok ki\u00EDr\u00E1sa PDF-be");
		btnPdf.setFont(new Font("Arial", Font.BOLD, 13));
		btnPdf.setBackground(new Color(0, 191, 255));
		btnPdf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.DataWriteToPdf();
			}
		});
		btnPdf.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnPdf.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnPdf.setBackground(new Color(0, 191, 255));
		    }
		});
		btnPdf.setBounds(10, 241, 208, 62);
		contentPane.add(btnPdf);
		
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		stm = new SzinTM(szintmn,0);
		
		Object rentmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magassag"};
		rentm = new RenTM(rentmn, 0);
		
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","N�v","Sz�lid�","Lak�hely","Magassag"};
		atm = new AllTM(alltmn, 0);

	}
}
