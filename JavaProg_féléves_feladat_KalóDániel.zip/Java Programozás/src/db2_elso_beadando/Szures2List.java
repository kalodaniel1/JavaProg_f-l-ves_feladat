package db2_elso_beadando;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Szures2List extends JDialog {
	private JTable table;
	private Szures2TM s2tm;
	public Szures2List(Szurok szurok, Szures2TM betm) {
		super(szurok, "Lista", true);
		getContentPane().setBackground(new Color(0, 255, 255));
		setUndecorated(true);
		s2tm = betm;
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		
		JButton btnBezar = new JButton("Bez\u00E1r");
		btnBezar.setBackground(new Color(0, 191, 255));
		btnBezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0, 191, 255));
		    }
		});
		btnBezar.setBounds(185, 258, 89, 31);
		getContentPane().add(btnBezar);
		btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 430, 236);
		getContentPane().add(scrollPane);
		
		table = new JTable(s2tm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 3; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0) tc.setPreferredWidth(30);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		TableRowSorter<Szures2TM> trs =
		(TableRowSorter<Szures2TM>)table.getRowSorter();
		trs.setSortable(0, false);


	}

}
