package db2_elso_beadando;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;

public class ErrSzinList extends JDialog {
	private JTable table;
	private ErrSzinTM estm;
	DbMethods dbm = new DbMethods();
	private Checker c = new Checker();

		public ErrSzinList(JFrame f, ErrSzinTM etm) {
		super(f,"Sz�ndarab hib�k list�ja", true);
		setUndecorated(true);
		getContentPane().setBackground(new Color(0, 255, 255));
		estm = etm;
		setBounds(40, 100, 640, 377);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		
		JButton btnBezar = new JButton("Bez\u00E1r\u00E1s");
		btnBezar.setBackground(new Color(0, 191, 255));
		btnBezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(0, 191, 255));
		    }
		});
		btnBezar.setBounds(518, 325, 112, 41);
		getContentPane().add(btnBezar);
		btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 620, 303);
		getContentPane().add(scrollPane);
		
		table = new JTable(estm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 6; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1 || i==5) tc.setPreferredWidth(30);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		
		
		JButton btnWriteToFile = new JButton("Ment\u00E9s");
		btnWriteToFile.setBackground(new Color(0, 191, 255));
		btnWriteToFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						dbm.openFile("szindarabErr.txt");
						dbm.WriteToTXTErrSzin(estm);
						dbm.closeFile();
						SM("Sikeres ki�r�s! A file megtal�lhat� szindarabErr.txt n�ven");
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnWriteToFile.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(0, 191, 255));
		    }
		});
		btnWriteToFile.setBounds(20, 325, 108, 41);
		getContentPane().add(btnWriteToFile);
		btnWriteToFile.setFont(new Font("Arial", Font.BOLD, 13));
		
		JLabel lblNewLabel = new JLabel("Hib\u00E1s sz\u00EDndarabok");
		lblNewLabel.setBounds(256, 338, 144, 28);
		getContentPane().add(lblNewLabel);
		
		TableRowSorter<RenTM> trs = (TableRowSorter<RenTM>)table.getRowSorter();
		trs.setSortable(0, false);
		

		}
		public void SM(String msg) {
			JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
		}
}
