package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ModRen extends JDialog {
	DbMethods dbm = new DbMethods();
	private final JPanel contentPanel = new JPanel();
	private JTextField rid;
	private JTextField nev;
	private JTextField szulido;
	private JTextField lak;
	private JTextField magassag;
	private JTextField nev2;
	private JTextField szulido2;
	private JTextField lak2;
	private JTextField magassag2;
	private Checker c = new Checker();

	public ModRen(JDialog d, String berid, String benev, String beszulido, String belak, String bemagassag,int n, RenTM rentm, int jel) {
		super(d,"Adatok m�dos�t�sa",true);
		setBounds(100, 100, 436, 224);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("K\u00F3d:");
			lblNewLabel.setBounds(10, 11, 74, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("N\u00E9v:");
			lblNewLabel_1.setBounds(10, 36, 74, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Sz\u00FClet\u00E9si id\u0151:");
			lblNewLabel_2.setBounds(10, 61, 97, 14);
			contentPanel.add(lblNewLabel_2);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("Lakhely:");
			lblNewLabel_3.setBounds(10, 86, 86, 14);
			contentPanel.add(lblNewLabel_3);
		}
		{
			JLabel lblNewLabel_4 = new JLabel("Magass\u00E1g:");
			lblNewLabel_4.setBounds(10, 111, 97, 14);
			contentPanel.add(lblNewLabel_4);
		}
		{
			rid = new JTextField(berid);
			rid.setEditable(false);
			rid.setBounds(114, 11, 126, 20);
			contentPanel.add(rid);
			rid.setColumns(10);
		}
		{
			nev = new JTextField(benev);
			nev.setEditable(false);
			nev.setBounds(91, 36, 149, 20);
			contentPanel.add(nev);
			nev.setColumns(10);
		}
		{
			szulido = new JTextField(beszulido);
			szulido.setEditable(false);
			szulido.setBounds(114, 61, 126, 20);
			contentPanel.add(szulido);
			szulido.setColumns(10);
		}
		{
			lak = new JTextField(belak);
			lak.setEditable(false);
			lak.setBounds(103, 86, 137, 20);
			contentPanel.add(lak);
			lak.setColumns(10);
		}
		{
			magassag = new JTextField(bemagassag);
			magassag.setEditable(false);
			magassag.setBounds(154, 114, 86, 20);
			contentPanel.add(magassag);
			magassag.setColumns(10);
		}
		{
			JButton btnMod = new JButton("M\u00F3dos\u00EDt");
			btnMod.setBackground(new Color(0, 191, 255));
			btnMod.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(n==0) {
						dbm.Connect();
						dbm.UpdateRen(RTF(rid), RTF2(nev2,nev), RTF2(szulido2,szulido), RTF2(lak2,lak), RTF2(magassag2,magassag));
						dbm.DisConnect();
					}
					else if(n==1) {
						if(modDataPc()>0) {
							dbm.CSVModRen(RTF(rid), RTF2(nev2,nev), RTF2(szulido2,szulido), RTF2(lak2,lak), RTF2(magassag2,magassag), rentm, jel);
						}
					}
					else if(n==2) {
						dbm.JSONModRen(RTF(rid), RTF2(nev2,nev), RTF2(szulido2,szulido), RTF2(lak2,lak), RTF2(magassag2,magassag), rentm, jel);
						dispose();
					}
				}
			});
			btnMod.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnMod.setBackground(new Color(0,0,255));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnMod.setBackground(new Color(0,191,255));
			    }
			});
			btnMod.setBounds(321, 151, 89, 23);
			contentPanel.add(btnMod);
			btnMod.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			nev2 = new JTextField();
			nev2.setBounds(250, 36, 149, 20);
			contentPanel.add(nev2);
			nev2.setColumns(10);
		}
		{
			szulido2 = new JTextField();
			szulido2.setBounds(250, 61, 126, 20);
			contentPanel.add(szulido2);
			szulido2.setColumns(10);
		}
		{
			lak2 = new JTextField();
			lak2.setBounds(250, 86, 137, 20);
			contentPanel.add(lak2);
			lak2.setColumns(10);
		}
		{
			magassag2 = new JTextField();
			magassag2.setBounds(250, 111, 86, 20);
			contentPanel.add(magassag2);
			magassag2.setColumns(10);
		}
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	public String RTF2(JTextField jtf2, JTextField jtf) {
		if(jtf2.getText().length()==0)
			return jtf.getText();
		return jtf2.getText();
	}
	public int modDataPc() {
		int pc = 0;
		if(c.filled(rid)) pc++;
		if(c.filled(nev2)) pc++;
		if(c.filled(szulido2)) pc++;
		if(c.filled(lak2)) pc++;
		if(c.filled(magassag2)) pc++;
		return pc;
	}
	
	
}
