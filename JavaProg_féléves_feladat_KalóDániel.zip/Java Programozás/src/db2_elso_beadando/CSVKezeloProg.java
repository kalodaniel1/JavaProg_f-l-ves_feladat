package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class CSVKezeloProg extends JFrame {

	private JPanel contentPane;
	private SzinTM stm;
	private RenTM rentm;
	private AllTM atm;
	private ErrSzinTM estm;
	private ErrRenTM ertm;
	DbMethods dbm = new DbMethods();
	
	public CSVKezeloProg(ChooseType choosetype) {
		super("Kezd�lap");
		setUndecorated(true);
		setFont(new Font("Arial", Font.PLAIN, 12));
		setForeground(Color.GRAY);
		setBackground(Color.GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 575, 395);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new LineBorder(new Color(25, 25, 112), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JButton btnSzinLista = new JButton("Sz\u00EDndarabok list\u00E1ja");
		btnSzinLista.setBackground(new Color(0, 191, 255));
		btnSzinLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stm = dbm.CsvReaderSzin();
				SzinList sl = new SzinList(CSVKezeloProg.this, stm);
				sl.setVisible(true);
			}
		});
		btnSzinLista.setBounds(10, 178, 160, 40);
		contentPane.add(btnSzinLista);
		btnSzinLista.setFont(new Font("Arial", Font.BOLD, 13));
		btnSzinLista.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzinLista.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzinLista.setBackground(new Color(0, 191, 255));
		    }
		});
		
		JButton btnRenLista = new JButton("Rendez\u0151k list\u00E1ja");
		btnRenLista.setBackground(new Color(0, 191, 255));
		btnRenLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rentm = dbm.CsvReaderRen();
				RenList rl = new RenList(CSVKezeloProg.this, rentm);
				rl.setVisible(true);
			}
		});
		btnRenLista.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnRenLista.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnRenLista.setBackground(new Color(0, 191, 255));
		    }
		});
		btnRenLista.setBounds(416, 178, 149, 40);
		contentPane.add(btnRenLista);
		btnRenLista.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnUjAdat = new JButton("\u00DAj adatsor");
		btnUjAdat.setBackground(new Color(0, 191, 255));
		btnUjAdat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChooseInsert ci = new ChooseInsert(CSVKezeloProg.this);
				ci.setVisible(true);
			}
		});
		btnUjAdat.setBounds(219, 229, 160, 40);
		contentPane.add(btnUjAdat);
		btnUjAdat.setFont(new Font("Arial", Font.BOLD, 13));
		btnUjAdat.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnUjAdat.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnUjAdat.setBackground(new Color(0, 191, 255));
		    }
		});
		
		JButton btnAllList = new JButton("Minden adat kilist\u00E1z\u00E1sa");
		btnAllList.setBackground(new Color(0, 191, 255));
		btnAllList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atm = dbm.CSVReaderAll();
				AllList al = new AllList(CSVKezeloProg.this, atm);
				al.setVisible(true);
			}
		});
		btnAllList.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnAllList.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnAllList.setBackground(new Color(0, 191, 255));
		    }
		});
		btnAllList.setBounds(197, 178, 196, 40);
		contentPane.add(btnAllList);
		btnAllList.setFont(new Font("Arial", Font.BOLD, 13));
		
		ImageIcon icon = new ImageIcon("logo.png");
		String logo = "src/logo.png";
		JLabel lblLogo = new JLabel(new ImageIcon(logo));
		lblLogo.setBounds(145, 11, 281, 134);
		contentPane.add(lblLogo);
		
		JLabel lblX = new JLabel("X");
		lblX.setFont(new Font("Arial", Font.BOLD, 13));
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblX.setForeground(new Color(255,0,0));
				
			}
			public void mouseExited(MouseEvent e) {
				lblX.setForeground(new Color(0,0,0));
			}
		});
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setBounds(545, 11, 20, 20);
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(JOptionPane.showConfirmDialog(null, "Ezzel visszal�p a form�tum v�laszt�shoz. Biztos?", "Biztos?", JOptionPane.YES_NO_OPTION)==0) {
					ChooseType ct = new ChooseType(null);
					ct.setVisible(true);
					dispose();
				}
			}
		});
		contentPane.add(lblX);
		
		JButton btnErrors = new JButton("Hib\u00E1k keres\u00E9se");
		btnErrors.setBackground(new Color(0, 191, 255));
		btnErrors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				estm = dbm.CSVsearchErrorsSzin();
				ertm = dbm.CSVsearchErrorsRen();
				ErrSzinList esl = new ErrSzinList(CSVKezeloProg.this, estm);
				ErrRenList erl = new ErrRenList(CSVKezeloProg.this,ertm);
				if(estm.getRowCount()>0)
					esl.setVisible(true);
				if(ertm.getRowCount()>0)
					erl.setVisible(true);
			}
		});
		btnErrors.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnErrors.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnErrors.setBackground(new Color(0, 191, 255));
		    }
		});
		btnErrors.setBounds(369, 280, 196, 40);
		btnErrors.setFont(new Font("Arial", Font.BOLD, 13));
		contentPane.add(btnErrors);
		
		JButton btnPdf = new JButton("Adatok ki\u00EDr\u00E1sa PDF-be");
		btnPdf.setBackground(new Color(0, 191, 255));
		btnPdf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.DataWriteToPdf();
			}
		});
		btnPdf.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnPdf.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnPdf.setBackground(new Color(0, 191, 255));
		    }
		});
		btnPdf.setFont(new Font("Arial", Font.BOLD, 13));
		btnPdf.setBounds(10, 280, 216, 40);
		contentPane.add(btnPdf);
		
		
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		stm = new SzinTM(szintmn,0);
		
		Object rentmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magassag"};
		rentm = new RenTM(rentmn, 0);
		
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","N�v","Sz�lid�","Lak�hely","Magassag"};
		atm = new AllTM(alltmn, 0);

	}
}
