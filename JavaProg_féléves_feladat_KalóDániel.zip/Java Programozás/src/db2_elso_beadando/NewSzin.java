package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JComboBox;

public class NewSzin extends JDialog {
	DbMethods dbm = new DbMethods();
	private final JPanel contentPanel = new JPanel();
	private JTextField szid;
	private JTextField cim;
	private JTextField mikor;
	private JTextField ar;
	private JTextField jatekido;
	private JComboBox rendezo;
	private Statement s = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private ArrayList<String> ridStr;
	DbMethods dbm1 = new DbMethods();
	private Checker c = new Checker();

	public NewSzin(JFrame f, int n) {
		super(f, "�j Sz�ndarab felvitele", true);
		setBounds(100, 100, 364, 223);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("K\u00F3d:");
		lblNewLabel.setBounds(10, 14, 46, 14);
		contentPanel.add(lblNewLabel);
		
		szid = new JTextField();
		szid.setBounds(118, 8, 86, 20);
		contentPanel.add(szid);
		szid.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("C\u00EDm:");
		lblNewLabel_1.setBounds(10, 39, 56, 14);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mikort\u00F3l:");
		lblNewLabel_2.setBounds(10, 64, 73, 14);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Jegy \u00E1r:");
		lblNewLabel_3.setBounds(10, 89, 73, 14);
		contentPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("J\u00E1t\u00E9kid\u0151:");
		lblNewLabel_4.setBounds(10, 114, 86, 14);
		contentPanel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Rendez\u0151 ID:");
		lblNewLabel_5.setBounds(10, 139, 86, 14);
		contentPanel.add(lblNewLabel_5);
		
		cim = new JTextField();
		cim.setBounds(118, 33, 181, 20);
		contentPanel.add(cim);
		cim.setColumns(10);
		
		mikor = new JTextField();
		mikor.setBounds(118, 58, 137, 20);
		contentPanel.add(mikor);
		mikor.setColumns(10);
		
		ar = new JTextField();
		ar.setBounds(118, 83, 86, 20);
		contentPanel.add(ar);
		ar.setColumns(10);
		
		jatekido = new JTextField();
		jatekido.setBounds(118, 108, 86, 20);
		contentPanel.add(jatekido);
		jatekido.setColumns(10);
		
		JButton btnBeszur = new JButton("Besz\u00FAr\u00E1s");
		btnBeszur.setBackground(new Color(0, 191, 255));
		btnBeszur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(n==0) {
					if(!filledTF(szid)) SM("A k�d mez� �res");
					else if(!goodInt(szid)) SM("A k�d mez�ben hib�s sz�m van");
					else if(!filledTF(cim)) SM("A cim mez� �res");
					else if(!filledTF(mikor)) SM("Mikort�l mez� �res");
					else if(!goodDate(mikor)) SM("A mikort�l mez�ben hib�s d�tum van");
					else if(!filledTF(ar)) SM("Az �r mez� �res");
					else if(!goodInt(ar)) SM("Az ar mez� hib�s");
					else if(!filledTF(jatekido)) SM("A j�t�kid� mez� �res");
					else if(!goodInt(jatekido)) SM("A j�t�kid� mez� hib�s");
					else {
						dbm.Connect();
						dbm.InsertSzin(RTF(szid), RTF(cim),	RTF(mikor), RTF(ar), RTF(jatekido), RTF2(rendezo));
						dbm.DisConnect();
					}
				}
				else if(n==1) {
					if(c.filled(szid, "K�D"))
						if(c.goodInt(szid, "K�D"))
							if(c.filled(cim, "C�M"))
								if(c.filled(mikor, "MIKOR"))
									if(c.goodDate(mikor, "MIKOR"))
										if(c.filled(ar, "�R"))
											if(c.goodInt(ar, "�R"))
												if(c.filled(jatekido, "J�T�KID�"))
													if(c.goodInt(jatekido, "J�T�KID�"))
														dbm.CSVInsertSzin(RTF(szid), RTF(cim),	RTF(mikor), RTF(ar), RTF(jatekido), RTF2(rendezo));
				}
				else if(n==2) {
					if(c.filled(szid, "K�D"))
						if(c.goodInt(szid, "K�D"))
							if(c.filled(cim, "C�M"))
								if(c.filled(mikor, "MIKOR"))
									if(c.goodDate(mikor, "MIKOR"))
										if(c.filled(ar, "�R"))
											if(c.goodInt(ar, "�R"))
												if(c.filled(jatekido, "J�T�KID�"))
													if(c.goodInt(jatekido, "J�T�KID�"))
														dbm.JSONInsertSzin(RTF(szid), RTF(cim),	RTF(mikor), RTF(ar), RTF(jatekido), RTF2(rendezo));
				}
			}
		});
		btnBeszur.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBeszur.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBeszur.setBackground(new Color(0, 191, 255));
		    }
		});
		btnBeszur.setBounds(210, 150, 109, 23);
		contentPanel.add(btnBeszur);
		btnBeszur.setFont(new Font("Arial", Font.BOLD, 13));
		if(n==0) {
			dbm1.Connect();
			ridStr = dbm1.readRid();
			dbm1.DisConnect();
			Object[] real = ridStr.toArray();
			rendezo = new JComboBox(real);
		}
		else if(n==1) {
			ridStr=dbm1.CSVReadRenKod();
			Object[] real = ridStr.toArray();
			rendezo = new JComboBox(real);
		}
		else if(n==2) {
			ridStr = dbm.JSONReadRenKod();
			Object[] real = ridStr.toArray();
			rendezo = new JComboBox(real);
		}
		rendezo.setBounds(118, 135, 86, 22);
		contentPanel.add(rendezo);
		
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public String RTF2(JComboBox jcb) {
		String str = jcb.getSelectedItem().toString();
		return str;
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
