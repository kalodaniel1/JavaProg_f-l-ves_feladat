package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class ChooseInsert extends JDialog {

	private final JPanel contentPanel = new JPanel();

	public ChooseInsert(JFrame f) {
		setUndecorated(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 255, 255));
		contentPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		{
			JLabel lblNewLabel = new JLabel("Melyik t\u00E1bl\u00E1ba szeretne beilleszteni?");
			lblNewLabel.setBounds(129, 46, 295, 44);
			contentPanel.add(lblNewLabel);
		}
		{
			JButton btnSzin = new JButton("Sz\u00EDndarab");
			btnSzin.setBackground(new Color(0, 191, 255));
			btnSzin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
						NewSzin ns = new NewSzin(null,0);
						ns.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
						NewSzin ns = new NewSzin(null,1);
						ns.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
						NewSzin ns = new NewSzin(null,2);
						ns.setVisible(true);
					}
				}
			});
			btnSzin.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnSzin.setBackground(new Color(0,0,255));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnSzin.setBackground(new Color(0, 191, 255));
			    }
			});
			btnSzin.setBounds(49, 170, 120, 44);
			contentPanel.add(btnSzin);
			btnSzin.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			JButton btnRen = new JButton("Rendez\u0151");
			btnRen.setBackground(new Color(0, 191, 255));
			btnRen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(f.getClass().getName().equals("db2_elso_beadando.ABKezeloProg")) {
						NewRen nr = new NewRen(null,0);
						nr.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.CSVKezeloProg")) {
						NewRen nr = new NewRen(null,1);
						nr.setVisible(true);
					}
					else if(f.getClass().getName().equals("db2_elso_beadando.JSONKezeloProg")) {
						NewRen rs = new NewRen(null,2);
						rs.setVisible(true);
					}
				}
			});
			btnRen.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnRen.setBackground(new Color(0,0,255));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnRen.setBackground(new Color(0, 191, 255));
			    }
			});
			btnRen.setBounds(266, 170, 120, 44);
			contentPanel.add(btnRen);
			btnRen.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			JButton btnBezar = new JButton("Bez\u00E1r");
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(0,0,255));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(0, 191, 255));
			    }
			});
			btnBezar.setBackground(new Color(0, 191, 255));
			btnBezar.setBounds(180, 245, 89, 44);
			contentPanel.add(btnBezar);
			btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		}
	}
}
