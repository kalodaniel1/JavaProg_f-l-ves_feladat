package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChooseType extends JFrame {

	private JPanel contentPane;

	public ChooseType(Login login) {
		super("Form�tum v�laszt�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 436, 200);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("Milyen form\u00E1tummal szeretne dolgozni?");
		lblNewLabel.setBounds(109, 43, 251, 14);
		contentPane.add(lblNewLabel);
		
		String[] types = {"V�lassz!","SQLite DB","CSV","JSON"};
		JComboBox comboBox = new JComboBox(types);
		comboBox.setBounds(137, 69, 126, 22);
		contentPane.add(comboBox);
		
		JButton btnGo = new JButton("Mehet");
		btnGo.setBackground(new Color(0, 191, 255));
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tipus = RTF2(comboBox);
				if(tipus.equals("SQLite DB")) {
					ABKezeloProg abkezel = new ABKezeloProg(ChooseType.this);
					abkezel.setVisible(true);
					dispose();
				}
				else if(tipus.equals("CSV"))
				{
					CSVKezeloProg csvkezel = new CSVKezeloProg(ChooseType.this);
					csvkezel.setVisible(true);
					dispose();
				}
				else if(tipus.equals("JSON"))
				{
					JSONKezeloProg jsonkezel = new JSONKezeloProg(ChooseType.this);
					jsonkezel.setVisible(true);
					dispose();
				}
			}
		});
		btnGo.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnGo.setBackground(new Color(0,0,255));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnGo.setBackground(new Color(0, 191, 255));
		    }
		});
		btnGo.setBounds(155, 113, 89, 23);
		contentPane.add(btnGo);
	}
	
	public String RTF2(JComboBox jcb) {
		String str = jcb.getSelectedItem().toString();
		return str;
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
}
